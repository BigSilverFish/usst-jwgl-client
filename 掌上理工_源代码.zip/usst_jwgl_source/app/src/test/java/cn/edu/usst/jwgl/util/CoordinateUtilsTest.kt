package cn.edu.usst.jwgl.util

import org.junit.Assert.*
import org.junit.Test

class CoordinateUtilsTest {

    @Test
    fun testBuildingCount() {
        // 13 本部北校区 + 3 本部南校区 + 4 军工路1100号校区 + 2 外校区 = 22
        assertEquals(22, CoordinateUtils.USST_BUILDINGS.size)
    }

    @Test
    fun testFindMatchingBuilding_Jungong1100Buildings() {
        // 勤学楼、达理楼、乐学楼合并为同一教学组团点位
        val qx = CoordinateUtils.findMatchingBuilding("1100号-勤学楼302")
        assertNotNull(qx)
        assertEquals("达理楼·勤学楼·乐学楼", qx?.name)
        assertEquals(31.299427, qx?.latitude ?: 0.0, 0.0001)

        val bx = CoordinateUtils.findMatchingBuilding("博学楼105")
        assertNotNull(bx)
        assertEquals("博学楼", bx?.name)
        assertEquals(31.299551, bx?.latitude ?: 0.0, 0.0001)

        val lx = CoordinateUtils.findMatchingBuilding("乐学楼201")
        assertNotNull(lx)
        assertEquals("达理楼·勤学楼·乐学楼", lx?.name)
        assertEquals(31.299427, lx?.latitude ?: 0.0, 0.0001)

        val gw = CoordinateUtils.findMatchingBuilding("格物楼401")
        assertNotNull(gw)
        assertEquals("格物楼·1100学生活动中心", gw?.name)
        assertEquals(31.299917, gw?.latitude ?: 0.0, 0.0001)

        val dl = CoordinateUtils.findMatchingBuilding("1100号图书馆报告厅")
        assertNotNull(dl)
        assertEquals("达理楼·勤学楼·乐学楼", dl?.name)
        assertEquals(31.299427, dl?.latitude ?: 0.0, 0.0001)

        val hd = CoordinateUtils.findMatchingBuilding("1100学生活动中心二楼")
        assertNotNull(hd)
        assertEquals("格物楼·1100学生活动中心", hd?.name)

        val jt = CoordinateUtils.findMatchingBuilding("1100申阶梯1")
        assertNotNull(jt)
        assertEquals("1100申阶梯·体育活动中心", jt?.name)
        assertEquals(31.300101, jt?.latitude ?: 0.0, 0.0001)

        val ty = CoordinateUtils.findMatchingBuilding("1100体育活动中心乒乓房")
        assertNotNull(ty)
        assertEquals("1100申阶梯·体育活动中心", ty?.name)
    }

    @Test
    fun testFindMatchingBuilding_CoverageRouting_Building1() {
        // Explicit directions
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教东201")?.name)
        assertEquals("一教西", CoordinateUtils.findMatchingBuilding("一教西102")?.name)
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教中101")?.name)

        // Room number based routing (<= 25 -> 东, > 25 -> 西)
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教101")?.name)
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教 204")?.name)
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教116")?.name)
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教221")?.name)

        // Offset > 25 -> 一教西
        assertEquals("一教西", CoordinateUtils.findMatchingBuilding("一教340")?.name)
        assertEquals("一教西", CoordinateUtils.findMatchingBuilding("第一教学楼150")?.name)

        // Default when no room number or direction
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("第一教学楼")?.name)
        assertEquals("一教东", CoordinateUtils.findMatchingBuilding("一教")?.name)
    }

    @Test
    fun testFindMatchingBuilding_CoverageRouting_Building3And4() {
        // Building 3 (已统一为单点三教)
        assertEquals("三教", CoordinateUtils.findMatchingBuilding("三教西105")?.name)
        assertEquals("三教", CoordinateUtils.findMatchingBuilding("三教东201")?.name)
        assertEquals("三教", CoordinateUtils.findMatchingBuilding("三教106")?.name)
        assertEquals("三教", CoordinateUtils.findMatchingBuilding("三教217")?.name)
        assertEquals("三教", CoordinateUtils.findMatchingBuilding("三教")?.name)

        // Building 4 (已统一为单点四教)
        assertEquals("四教", CoordinateUtils.findMatchingBuilding("四教西201")?.name)
        assertEquals("四教", CoordinateUtils.findMatchingBuilding("四教东302")?.name)
        assertEquals("四教", CoordinateUtils.findMatchingBuilding("四教105")?.name)
        assertEquals("四教", CoordinateUtils.findMatchingBuilding("四教221")?.name)
        assertEquals("四教", CoordinateUtils.findMatchingBuilding("四教")?.name)
    }

    @Test
    fun testFindMatchingBuilding_IndependentComprehensiveBuildings() {
        // Zone A
        assertEquals("综合楼A区", CoordinateUtils.findMatchingBuilding("综合楼A区201")?.name)
        assertEquals("综合楼A区", CoordinateUtils.findMatchingBuilding("综A101")?.name)
        assertEquals("综合楼A区", CoordinateUtils.findMatchingBuilding("综合A204")?.name)

        // Zone B
        assertEquals("综合楼B区", CoordinateUtils.findMatchingBuilding("综合楼B区105")?.name)
        assertEquals("综合楼B区", CoordinateUtils.findMatchingBuilding("综B203")?.name)

        // Zone C
        assertEquals("综合楼C区", CoordinateUtils.findMatchingBuilding("综合楼C区317")?.name)
        assertEquals("综合楼C区", CoordinateUtils.findMatchingBuilding("综C110")?.name)

        // Zone D
        assertEquals("综合楼D区", CoordinateUtils.findMatchingBuilding("综合楼D区402")?.name)
        assertEquals("综合楼D区", CoordinateUtils.findMatchingBuilding("综D301")?.name)

        // Fallback for general 综合楼 without zone
        assertEquals("综合楼A区", CoordinateUtils.findMatchingBuilding("教学综合楼")?.name)
    }

    @Test
    fun testFindMatchingBuilding_OtherPoints() {
        val zy = CoordinateUtils.findMatchingBuilding("卓越楼101")
        assertEquals("卓越楼", zy?.name)
        assertEquals("本部南校区", zy?.campus)

        val yj = CoordinateUtils.findMatchingBuilding("一教中201")
        assertEquals("一教东", yj?.name)
        assertEquals("本部北校区", yj?.campus)

        val sj = CoordinateUtils.findMatchingBuilding("四教西101")
        assertEquals("四教", sj?.name)
        assertEquals("本部南校区", sj?.campus)

        assertEquals("公共实验楼", CoordinateUtils.findMatchingBuilding("公共实验楼302")?.name)
        assertEquals("计算中心", CoordinateUtils.findMatchingBuilding("计算中心机房")?.name)
        assertEquals("光仪所", CoordinateUtils.findMatchingBuilding("光仪所201")?.name)
        assertEquals("国合楼", CoordinateUtils.findMatchingBuilding("国合楼报告厅")?.name)
        assertEquals("580体育活动中心", CoordinateUtils.findMatchingBuilding("580体育活动中心")?.name)
        assertEquals("580体育活动中心", CoordinateUtils.findMatchingBuilding("体育活动中心")?.name)
        assertEquals("新体育健身中心", CoordinateUtils.findMatchingBuilding("新体育健身中心")?.name)
        assertEquals("北校田径场", CoordinateUtils.findMatchingBuilding("北校田径场")?.name)
    }

    @Test
    fun testFindMatchingBuilding_NewCampuses() {
        val fx = CoordinateUtils.findMatchingBuilding("复兴路教学楼301")
        assertNotNull(fx)
        assertEquals("复兴路教学楼", fx?.name)
        assertEquals("复兴路校区", fx?.campus)
        assertEquals(31.211925, fx?.latitude ?: 0.0, 0.000001)
        assertEquals(121.460448, fx?.longitude ?: 0.0, 0.000001)

        val yk = CoordinateUtils.findMatchingBuilding("营口路教学楼102")
        assertNotNull(yk)
        assertEquals("营口路教学楼", yk?.name)
        assertEquals("营口路校区", yk?.campus)
        assertEquals(31.289567, yk?.latitude ?: 0.0, 0.000001)
        assertEquals(121.534146, yk?.longitude ?: 0.0, 0.000001)
    }

    @Test
    fun testFindNearestBuilding_RealPhoneLocationNearBuilding3() {
        // 真机在三教实测物理定位 (WGS-84 原生坐标)
        val phoneWgsLat = 31.297542
        val phoneWgsLng = 121.553112

        val (nearest, dist) = CoordinateUtils.findNearestBuildingFromWgs84(phoneWgsLat, phoneWgsLng)
        assertEquals("b_516_3j_e", nearest.id)
        assertTrue("物理距离应在200米之内，当前为: $dist", dist < 200.0)

        // 直接传入 GCJ-02 坐标测试
        val (nearestGcj, distGcj) = CoordinateUtils.findNearestBuilding(nearest.latitude, nearest.longitude)
        assertEquals("b_516_3j_e", nearestGcj.id)
        assertEquals(0.0, distGcj, 0.0001)
    }
}
